import { ArrowDown } from 'lucide-react';
import { useEffect, useRef } from 'react';
import { PhotoTunnel } from './PhotoTunnel';
import { useReducedMotion } from '../hooks/useReducedMotion';

export function Hero() {
  const visualRef = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  useEffect(() => {
    if (reduced) return;
    let scheduled = false;
    const update = () => {
      const progress = Math.max(0, Math.min(1, window.scrollY / (window.innerHeight * 0.77)));
      if (visualRef.current) {
        visualRef.current.style.opacity = String(1 - progress);
        visualRef.current.style.transform = `translateY(${-progress * 34}px)`;
      }
      scheduled = false;
    };
    const onScroll = () => { if (!scheduled) { scheduled = true; requestAnimationFrame(update); } };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => { window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); };
  }, [reduced]);
  return <section id="home" className="hero-track" aria-label="Welcome">
    <div className="hero-sticky" ref={visualRef}>
      <PhotoTunnel />
      <div className="hero-title-layer"><p className="hero-overline">A PORTFOLIO OF CURIOSITIES</p><h1>Avena Fan</h1><p className="hero-subtitle">PRODUCT <span>·</span> SCIENCE <span>·</span> EVERYTHING IN BETWEEN</p></div>
      <button className="hero-arrow" aria-label="Scroll to introduction" onClick={() => document.querySelector('#about')?.scrollIntoView({ behavior: reduced ? 'instant' : 'smooth' })}><ArrowDown size={25} strokeWidth={1.25} /><span>SCROLL TO EXPLORE</span></button>
      <span className="hero-index">01 — 04</span>
    </div>
  </section>;
}
