# Avena Fan — interactive portfolio

A one-page editorial portfolio built with **React 19 + Vite + TypeScript + Tailwind CSS 4** and a lightweight CSS 3D photo tunnel. There is no canvas/WebGL dependency: the tunnel uses `requestAnimationFrame` and transforms, allowing easy image swaps and avoiding heavyweight 3D rendering.

## Run locally

Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the URL printed by Vite (typically http://localhost:5173). Production build:

```bash
npm run build
npm run preview
```

## Customize

- **Experience and projects:** edit arrays in `src/data/content.ts`. Every entry includes `title`, `dates`, `description`. Add `details`, `images: [{ src, alt }]`, and/or `link` when available. Hover/focus shows the one-line teaser; click/tap expands the details panel. Empty details show a clearly labeled placeholder instead of fake project information.
- **Gallery photos:** edit `heroPhotos` in `src/data/content.ts`. The `src` field may reference external Unsplash assets or local assets such as `/photos/image.jpg`. Add your local files under `public/photos/`. `width` controls the displayed width, while `x`, `y`, and `z` control positioning; original image aspect ratios are preserved (`height: auto`, `fit=max`, no cropping).
- **Portrait:** update `portrait.src`. The introductory portrait frame is 4:5 and uses `object-fit: cover` by design; if you want the entire portrait shown without cropping, switch to `object-fit: contain` in `src/styles/global.css`.
- **Colors and fonts:** edit CSS custom properties at the top of `src/styles/global.css`. The initial theme is black; the bottom-right theme toggle persists choice to `localStorage`.
- **Text/layout:** components live in `src/components/`. The hero image effects are defined in `PhotoTunnel.tsx` and `Hero.tsx`.

## Behavior / accessibility

- The hero is full-viewport and sticky, and fades into the introduction on scroll.
- Eight ambient photographs recycle along the Z axis. Downward scrolling temporarily increases tunnel velocity. No page scroll is intercepted.
- Desktop nav becomes visible after scrolling beyond the hero. Mobile nav collapses into a menu button.
- Desktop hover/focus shows row teasers; click expands detail placeholders, future images, and links. On touch, tapping a row brings it to full opacity, reveals the teaser, and expands details.
- Reduced-motion system preferences stop the perpetual gallery and disable smooth scrolling/transitions.
- Native buttons, accessible labels, keyboard-focus styles, and `Escape` to dismiss the mobile menu are supported.

## Deploy to GitHub Pages or Vercel

Deploy using your normal Vite static hosting workflow (`npm run build`, output directory `dist`). For a GitHub Pages **project** site under `/avena-portfolio/`, set `base: '/avena-portfolio/'` in `vite.config.ts`; for Vercel or a root domain, leave as-is.

## Notes

Placeholder imagery is hosted on Unsplash and needs an internet connection. Image availability is subject to the image host. Replace with your own locally hosted images before launching. No tracking, backend, or form service is included.
